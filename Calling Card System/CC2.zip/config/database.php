<?php
/**
 * Database Configuration
 * Calling Card System
 */

// Database credentials
define('DB_HOST', 'localhost');
define('DB_USER', 'ndasphilsinc');
define('DB_PASS', '%aa}gX)ig=Yh');
define('DB_NAME', 'ndasphilsinc_callingcard_db');
define('DB_PORT', 3306);

// Site configuration
define('SITE_URL', 'https://tito.ndasphilsinc.com/callingcard/');
define('BASE_PATH', dirname(__DIR__));

// Upload paths
define('UPLOAD_PATH', BASE_PATH . '/uploads/');
define('UPLOAD_URL', SITE_URL . 'uploads/');

// Create upload directories if they don't exist
$upload_dirs = [
    UPLOAD_PATH . 'profiles/',
    UPLOAD_PATH . 'logos/',
    UPLOAD_PATH . 'products/'
];

foreach ($upload_dirs as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Database connection class
class Database {
    private static $instance = null;
    private $conn;
    
    private function __construct() {
        try {
            $this->conn = new PDO(
                "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch(PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->conn;
    }
    
    // Prevent cloning
    private function __clone() {}
    
    // Prevent unserialization
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

// Get database connection
function getDB() {
    return Database::getInstance()->getConnection();
}

