<?php
/**
 * Admin API Endpoints
 * Calling Card System
 */

require_once '../config/config.php';
require_once '../includes/functions.php';

requireAdmin();

header('Content-Type: application/json');

$db = getDB();
$companyId = getCurrentCompanyId();
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'admin_login':
        // Admin login for account tab
        $username = sanitize($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            jsonResponse(false, 'Username and password are required', null, 400);
        }
        
        $stmt = $db->prepare("SELECT admin_id, password FROM admins WHERE admin_id = ? AND company_id = ? AND is_active = 1");
        $stmt->execute([getCurrentUserId(), $companyId]);
        $admin = $stmt->fetch();
        
        if ($admin && verifyPassword($password, $admin['password'])) {
            $_SESSION['admin_logged_in'] = true;
            logActivity('admin', getCurrentUserId(), 'admin_account_login', 'Admin logged in via account tab');
            jsonResponse(true, 'Login successful');
        } else {
            jsonResponse(false, 'Invalid credentials', null, 401);
        }
        break;
        
    case 'update_profile':
        if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
            jsonResponse(false, 'Please login first', null, 401);
        }
        
        $firstName = sanitize($_POST['first_name'] ?? '');
        $middleName = sanitize($_POST['middle_name'] ?? '');
        $lastName = sanitize($_POST['last_name'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $contact = sanitize($_POST['contact_number'] ?? '');
        
        if (empty($firstName) || empty($lastName) || empty($email)) {
            jsonResponse(false, 'Required fields are missing', null, 400);
        }
        
        if (!isValidEmail($email)) {
            jsonResponse(false, 'Invalid email address', null, 400);
        }
        
        try {
            $stmt = $db->prepare("
                UPDATE admins 
                SET first_name = ?, middle_name = ?, last_name = ?, email = ?, contact_number = ?, updated_at = NOW()
                WHERE admin_id = ? AND company_id = ?
            ");
            $stmt->execute([$firstName, $middleName, $lastName, $email, $contact, getCurrentUserId(), $companyId]);
            
            logActivity('admin', getCurrentUserId(), 'update_profile', 'Updated admin profile');
            jsonResponse(true, 'Profile updated successfully');
        } catch (Exception $e) {
            jsonResponse(false, 'Error: ' . $e->getMessage(), null, 500);
        }
        break;
        
    case 'change_password':
        if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
            jsonResponse(false, 'Please login first', null, 401);
        }
        
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        
        if (empty($currentPassword) || empty($newPassword)) {
            jsonResponse(false, 'All password fields are required', null, 400);
        }
        
        if (strlen($newPassword) < MIN_PASSWORD_LENGTH) {
            jsonResponse(false, 'Password must be at least ' . MIN_PASSWORD_LENGTH . ' characters', null, 400);
        }
        
        // Verify current password
        $stmt = $db->prepare("SELECT password FROM admins WHERE admin_id = ? AND company_id = ?");
        $stmt->execute([getCurrentUserId(), $companyId]);
        $admin = $stmt->fetch();
        
        if (!$admin || !verifyPassword($currentPassword, $admin['password'])) {
            jsonResponse(false, 'Current password is incorrect', null, 401);
        }
        
        try {
            $stmt = $db->prepare("
                UPDATE admins 
                SET password = ?, updated_at = NOW()
                WHERE admin_id = ? AND company_id = ?
            ");
            $stmt->execute([hashPassword($newPassword), getCurrentUserId(), $companyId]);
            
            logActivity('admin', getCurrentUserId(), 'change_password', 'Admin changed password');
            jsonResponse(true, 'Password changed successfully');
        } catch (Exception $e) {
            jsonResponse(false, 'Error: ' . $e->getMessage(), null, 500);
        }
        break;
        
    case 'delete_user':
        if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
            jsonResponse(false, 'Please login first', null, 401);
        }
        
        $userId = $_POST['user_id'] ?? null;
        
        if (!$userId) {
            jsonResponse(false, 'User ID is required', null, 400);
        }
        
        try {
            // Verify user belongs to admin's company
            $stmt = $db->prepare("SELECT user_id FROM users WHERE user_id = ? AND company_id = ?");
            $stmt->execute([$userId, $companyId]);
            if (!$stmt->fetch()) {
                jsonResponse(false, 'User not found or access denied', null, 403);
            }
            
            $stmt = $db->prepare("UPDATE users SET is_active = 0 WHERE user_id = ?");
            $stmt->execute([$userId]);
            
            logActivity('admin', getCurrentUserId(), 'delete_user', "Deleted user ID: $userId");
            jsonResponse(true, 'User deleted successfully');
        } catch (Exception $e) {
            jsonResponse(false, 'Error: ' . $e->getMessage(), null, 500);
        }
        break;
        
    case 'delete_product':
        if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
            jsonResponse(false, 'Please login first', null, 401);
        }
        
        $productId = $_POST['product_id'] ?? null;
        
        if (!$productId) {
            jsonResponse(false, 'Product ID is required', null, 400);
        }
        
        try {
            // Verify product belongs to admin's company
            $stmt = $db->prepare("SELECT image_path FROM products WHERE product_id = ? AND company_id = ?");
            $stmt->execute([$productId, $companyId]);
            $product = $stmt->fetch();
            
            if (!$product) {
                jsonResponse(false, 'Product not found or access denied', null, 403);
            }
            
            // Delete file
            if ($product['image_path'] && file_exists($product['image_path'])) {
                deleteFile($product['image_path']);
            }
            
            $stmt = $db->prepare("UPDATE products SET is_active = 0 WHERE product_id = ?");
            $stmt->execute([$productId]);
            
            logActivity('admin', getCurrentUserId(), 'delete_product', "Deleted product ID: $productId");
            jsonResponse(true, 'Product deleted successfully');
        } catch (Exception $e) {
            jsonResponse(false, 'Error: ' . $e->getMessage(), null, 500);
        }
        break;
        
    default:
        jsonResponse(false, 'Invalid action', null, 400);
}

