<?php
/**
 * Get Company API
 * Calling Card System
 */

require_once '../config/config.php';
require_once '../includes/functions.php';

requireSuperAdmin();

header('Content-Type: application/json');

$id = $_GET['id'] ?? null;

if (!$id) {
    jsonResponse(false, 'Company ID is required', null, 400);
}

$db = getDB();
$stmt = $db->prepare("SELECT * FROM company WHERE company_id = ?");
$stmt->execute([$id]);
$company = $stmt->fetch();

if ($company) {
    jsonResponse(true, 'Company found', $company);
} else {
    jsonResponse(false, 'Company not found', null, 404);
}

